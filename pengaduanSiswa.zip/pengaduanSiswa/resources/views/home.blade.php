@extends('layouts.main')
@section('container')
<div class="row">
    <div class="col-12 mb-4">
        <img src="{{ asset('img/DSCF9408.jpg') }}" class="d-block rounded-3" height="700" width="100%"
                  alt="...">
    </div>
    <div class="col-12">
            <Article>
                <h1 class="fw-bold mb-2">Apa itu Layanan Pengaduan Siswa ?</h1>
                <p>Pengaduan siswa adalah penyampaian keluhan oleh siswa kepada pihak sekolah atas pelayanan yang tidak sesuai dengan standar pelayanan, atau pengabaian kewajiban dan/atau pelanggaran larangan.
                      Penanganan pengaduan siswa adalah proses kegiatan yang meliputi penerimaan, pencatatan, penelaahan, tindak lanjut penyaluran tindaklanjut, pengarsipan, pemantauan dan pelaporan.
                      Pengadu adalah seluruh pihak baik warganegara maupun penduduk baik orang perorangan, kelompok maupun badan hukum yang menyampaikan pengaduan kepada Pengelola pengaduan pelayanan sekolah.
                      Siswa adalah seluruh pihak, baik kelas 10, kelas 11 , maupun kelas 12 yang berkedudukan sebagai penerima manfaat pelayanan di bidang Komunikasi dan informatika, baik secara langsung maupun tidak langsung.</p>
            </Article>
      
    </div>
    <div class="col-12">
        <a href="/aspirasi" class="btn btn-danger fw-bold" style="color: white; background-color :brown;">Ajukan Aspirasi</a>
    </div>
</div>
@endsection