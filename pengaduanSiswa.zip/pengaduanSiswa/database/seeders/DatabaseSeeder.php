<?php

namespace Database\Seeders;

use App\Models\Admin;
use App\Models\Aspirasi;
use App\Models\Input_aspirasi;
use App\Models\Kategori;
use App\Models\Siswa;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
         //Input Data Kategori
         Kategori::create(
            [
                'ket_kategori' => 'Kebersihan'
            ]
        );
        Kategori::create(
            [
                'ket_kategori' => 'Keamanan'
            ]
        );
        Kategori::create(
            [
                'ket_kategori' => 'Kesehatan'
            ]
        );
        //Input Data Siswa
        Siswa::create([
            'id' => '20209094',
            'nama' => 'Muhammad Rizky Handi',
            'kelas' => 'XII Tel 12',
        ]);
        Siswa::create([
            'id' => '20209095',
            'nama' => 'Muhammad Altaf',
            'kelas' => 'XII Tel 11',
        ]);
        Siswa::create([
            'id' => '20209096',
            'nama' => 'Raka Herdika Ramadhan',
            'kelas' => 'XII Tel 8',
        ]);
        //Input Data Aspirasi
        //   Aspirasi::create([
        //     'id' => 1,
        //     'id_aspirasi' => 1,
        //     'kategori_id' => 2,
        //     'status' => 'Menunggu',
        // ]);
        // Aspirasi::create([
        //     'id' => 2,
        //     'id_aspirasi' => 2,
        //     'kategori_id' => 3,
        //     'status' => 'Menunggu',
        // ]);
        //Input Aspirasi
        // Input_aspirasi::create([
        //     'nis' => '20209094',
        //     'kategori_id' => '2',
        //     'lokasi' => 'SMK Telkom Jakarta',
        //     'ket' => 'Kehilangan helm',
        // ]);
        // Input_aspirasi::create([
        //     'nis' => '20209095',
        //     'kategori_id' => '3',
        //     'lokasi' => 'SMK Telkom',
        //     'ket' => 'Kehilangan kunci',
        // ]);
        //input data admin
        Admin::create([
            'username' => 'admin',
            'password' => bcrypt('password'),
        ]);
    }
}