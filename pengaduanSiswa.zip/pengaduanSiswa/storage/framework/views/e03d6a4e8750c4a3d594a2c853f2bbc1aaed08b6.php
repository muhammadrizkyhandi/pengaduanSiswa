<nav class="navbar navbar-expand-lg p-lg-3 p-sm-0 p-md-3" style="background-color: #810101;">
    <div class="container">
        <a class="navbar-brand fw-bold text-white fs-3" href="/admin">Aspirasi Siswa</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
            <form action="/logout" method="post">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm text-white" >Log Out</button>
            </form>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\pengaduanSiswa\resources\views/partials/navbar-admin.blade.php ENDPATH**/ ?>